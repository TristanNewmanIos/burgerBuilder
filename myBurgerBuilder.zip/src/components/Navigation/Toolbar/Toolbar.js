import React from 'react';
import classes from './Toolbar.css';
import Logo from '../../Logo/Logo';
import NavigationItems from '../NavigationItems/NavigationItems';
import Button from '../../UI/Button/Button.js';
import DrawerToggle from '../SideDrawer/DrawerToggle/DrawerToggle';


const toolbar = (props) =>(
  /*height could be adjusted by passing in a value through props to Logo like,
  '<Logo height='11%'/>', then set height to props.height in Logo, via inline
  styling*/

  // <div >
  //   Menu
  // </div>

  // <Button clicked={props.openSideDrawer}>Menu</Button>

  <header className={classes.Toolbar}>

    <DrawerToggle clicked={props.drawerToggleClicked}/>

    <div className={classes.Logo}>
      <Logo/>
    </div>
    <nav className={classes.DesktopOnly}>
      <NavigationItems />
    </nav>
  </header>
);

export default toolbar;
