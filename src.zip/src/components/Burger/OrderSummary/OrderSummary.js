import React from 'react';
import Aux from '../../../hoc/Aux';
import Button from '../../UI/Button/Button';

const orderSummary = (props) =>{
  //Object.keys() transforms ingredients into an array of keys
  const ingredientSummary = Object.keys(props.ingredients)
  //array.map(function=>{}) goes through every element in the function and performs
  //the function to it.
  .map(igKey =>{
      //<span style> is called 'inline styling'
      return <li key= {igKey}>
              <span style= {{textTransform:'capitalize'}}>
                {igKey}
              </span>:
                {props.ingredients[igKey]}
            </li>
    }
  );


  return(
    <Aux>
      <h3>Your Order</h3>
      <p>A delicious burger with the following ingredients:</p>
      <ul>
        {ingredientSummary}
      </ul>
      <p><strong>Total Price: {props.price}</strong></p>
      <p>Continue to checkout?</p>
      <Button clicked= {props.purchaseCancelled} btnType= 'Danger'>CANCEL</Button>
      <Button clicked= {props.purchaseContinued} btnType= 'Success'>CONTINUE</Button>
    </Aux>
  );

};

export default orderSummary;
