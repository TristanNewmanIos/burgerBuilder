import React, { Component } from 'react';
import Aux from '../../hoc/Aux';
import classes from './Layout.css';
import Toolbar from '../Navigation/Toolbar/Toolbar';
import SideDrawer from '../Navigation/SideDrawer/SideDrawer';

class Layout extends Component {
  state = {
    showSideDrawer: true
  }

  sideDrawerClosedHandler = () =>{
    this.setState({showSideDrawer: false});
  }

  // sideDrawerOpenedHandler = () =>{
  //   this.setState({showSideDrawer: true});
  // }

  sideDrawerToggleHandler = () =>{
    this.setState({showSideDrawer: true});
  }

  render () {
    return(
      // <div>
      //   Toolbar, SideDrawer, Backdrop
      // </div>
      /*SideDrawer is used in the Layout since we want it
      availble all the time on smaller devices*/
      <Aux>
        // <Toolbar openSideDrawer={this.sideDrawerOpenedHandler}/>
        <Toolbar drawerToggleClicked={this.sideDrawerToggleHandler}/>
        <SideDrawer
          open={this.state.showSideDrawer} closed={this.sideDrawerClosedHandler}/>
        <main className={classes.Content}>
          {this.props.children}
        </main>
      </Aux>
    );
  }
}


export default Layout;
