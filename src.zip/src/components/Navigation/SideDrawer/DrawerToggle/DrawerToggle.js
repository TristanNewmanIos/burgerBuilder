import React from 'react';

const drawerToggle = (props) => (
  <div onClick={props.clicked} >MENU</div>
)

export default drawerToggle;
